
public interface Product {
    String id();
    String name();
    Money basePrice();
}