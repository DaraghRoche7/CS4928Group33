public class Main {
    public static void main(String[] args) {
        Money m1 = Money.of(20.00);
        Money m2 = Money.of(7.50);

        System.out.println("Add: " + m1.add(m2));        // $27.50
        System.out.println("Subtract: " + m1.subtract(m2)); // $12.50
        System.out.println("Multiply: " + m2.multiply(3));  // $22.50
        System.out.println("Double: " + m1.doubleValue());  // $40.00
    }
}
