package main.java.decorators;

import main.java.order.Money;

public interface Priced {
    Money price();
}
