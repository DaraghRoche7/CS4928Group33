import java.math.BigDecimal;

 

public final class SimpleProduct implements Product {

    private final String id;
    private final String name;
    private final Money basePrice; 

    public SimpleProduct(String id, String name, Money basePrice) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("Product id cannot be null or blank");
        }

        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Product name cannot be null or blank");
        }

        if (basePrice == null) {
            throw new IllegalArgumentException("Base price cannot be null");
        }

        if (basePrice.asBigDecimal().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Base price cannot be negative");
        }

        this.id = id;
        this.name = name;
        this.basePrice = basePrice;
    }

    @Override
    public String id() {
        return id;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public Money basePrice() {
        return basePrice;
    }

    @Override
    public String toString() {
        return "SimpleProduct{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", basePrice=" + basePrice +
                '}';
    }
}
